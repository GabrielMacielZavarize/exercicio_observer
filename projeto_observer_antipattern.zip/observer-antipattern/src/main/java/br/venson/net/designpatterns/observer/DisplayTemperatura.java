package br.venson.net.designpatterns.observer;

public class DisplayTemperatura {

    public void atualizar(double temperatura) {
        System.out.println("Temperatura atual: " + temperatura + "C");
    }
}
